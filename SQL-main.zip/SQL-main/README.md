MYSQL：

1.導入DB->開啟select1->執行

2.導入DB->開啟select2->執行

3.導入DB->開啟select3->執行

4.導入DB->開啟select4->執行



MongoSQL：

複製mongo\_queries內容貼入shell

